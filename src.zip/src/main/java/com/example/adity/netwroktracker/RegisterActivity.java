package com.example.adity.netwroktracker;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.adity.netwroktracker.DataBaseHelpers.DBHelper;

public class RegisterActivity extends AppCompatActivity {

    Button btRegister;
    EditText etUserName, etPassword, etConfrimPassword, etHint;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });


        etUserName = (EditText) findViewById(R.id.etUserName); etUserName.setText("aditya");
        etPassword = (EditText) findViewById(R.id.etPassword); etPassword.setText("aditya123");
        etConfrimPassword = (EditText) findViewById(R.id.etConfirmPassword); etConfrimPassword.setText("aditya123");
        etHint = (EditText) findViewById(R.id.etHint); etHint.setText("aditya123");

        btRegister = (Button) findViewById(R.id.btRegister);
        btRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userName = etUserName.getText().toString().trim();
                String password = etPassword.getText().toString();
                String Cpassword = etConfrimPassword.getText().toString();
                String hint  = etHint.getText().toString();

                if(password.equals(Cpassword)){
                    if(DBHelper.getInstance().createUser(getApplicationContext(),userName,password,hint)){
                        Toast.makeText(getApplicationContext(),"SignUp Successful", Toast.LENGTH_SHORT).show();
                        finishActivity(LoginActivity.RESULT_OK);
                        finish();
                    }
                }
                else{
                    Toast.makeText(getApplicationContext(),"Password MisMatch", Toast.LENGTH_LONG).show();
                }



            }
        });


    }

}
