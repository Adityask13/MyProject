package com.example.adity.netwroktracker.DataBaseHelpers;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.support.annotation.Nullable;


// pending delete and updatea

public class DataProvider extends ContentProvider {

    public static final String PROVIDER_NAME = "com.nt.app.provider.MyProvider";
    private static final int DATABASE_VERSION = 1;

    //---for database use start---
    private SQLiteDatabase mDb;
    private static final String DATABASE_NAME = "MyDataBase.db";
    private static final String LOGIN_TABLE = "Login";
    private static final String PLAN_TABLE = "Plan";

    //Uri for matching the database
    private static final int LOGIN = 1;
    private static final int PLAN = 2;
    private static final int PLANID = 3;
    private static final int LOGINID = 4;

    //Content Uri for application usage
    public static final Uri LOGIN_URI = Uri.parse("content://"
            + PROVIDER_NAME + "/" + LOGIN_TABLE);

    public static final Uri PLAN_URI = Uri.parse("content://"
            + PROVIDER_NAME + "/" + PLAN_TABLE);


    /** Uri matcher for creating a provision to users for accessing DB
     *
     */
    private static final UriMatcher uriMatcher;
    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(PROVIDER_NAME, LOGIN_TABLE, LOGIN);
        uriMatcher.addURI(PROVIDER_NAME, LOGIN_TABLE + "/#", LOGINID);
        uriMatcher.addURI(PROVIDER_NAME, PLAN_TABLE, PLAN);
        uriMatcher.addURI(PROVIDER_NAME, PLAN_TABLE + "/#", PLANID);
    }

    //Common columns
    public static final String KEY_ROWID = "_id";
    public static final String KEY_PLANID = "planId";

    //KEYS for Login Screen
    public static final String KEY_USERID = "userId";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_HINT = "hint";
    public static final String KEY_SAVE_PWD = "savePwd";
    public static final String KEY_IS_LOGIN = "isLogin";

    //KEYS for Plans Screen
    public static final String KEY_PLAN_LOGINID = "loginId";
    public static final String KEY_PLAN_NAME = "name";
    public static final String KEY_PLAN_RADIUS = "radius";
    public static final String KEY_PLAN_LAT_LONG = "lat_long";


    /* Command to create a Login Table*/
    private static final String CREATE_LOGIN_TABLE =
            "create table " + LOGIN_TABLE +
                    " (_id integer primary key autoincrement, "
                    + "userId text not null, "
                    + "password text not null, "
                    + "hint text not null, "
                    + "isLogin boolean, "
                    + "savePwd boolean);";

    /* Command to create a Plan Table*/
    private static final String CREATE_PLAN_TABLE =
            "create table " + PLAN_TABLE +
                    " (_id integer primary key autoincrement, "
                    + "loginId integer, "
                    + "name text not null, "
                    + "radius integer, "
                    + "lat_long text);";



    @Override
    public boolean onCreate() {
        Context context = getContext();
        DBHelper dbHelper = new DBHelper(context);
        mDb = dbHelper.getWritableDatabase();
        return (mDb == null) ? false : true;
    }

    @Nullable
    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        Cursor c = null;
        SQLiteQueryBuilder sqlBuilder = new SQLiteQueryBuilder();
        switch (uriMatcher.match(uri)) {
            case LOGIN:
                sqlBuilder.setTables(LOGIN_TABLE);
                break;
            case PLAN:
                sqlBuilder.setTables(PLAN_TABLE);
                break;
            case PLANID:
                sqlBuilder.setTables(PLAN_TABLE);
                sqlBuilder.appendWhere("(_id = " + uri.getPathSegments().get(1) + ")");
                break;
        }

        c = sqlBuilder.query(mDb, projection, selection, selectionArgs, null,
                null, sortOrder);

        // ---register to watch a content URI for changes---
        c.setNotificationUri(getContext().getContentResolver(), uri);
        return c;
    }

    @Nullable
    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(Uri uri, ContentValues values) {
        long rowID = 0;
        switch (uriMatcher.match(uri)) {
            case LOGIN: // re-check if user already exists
                Cursor mCursor = mDb.query(true, LOGIN_TABLE, null,
                        KEY_USERID + "='" + values.getAsString(KEY_USERID) + "'",
                        null, null, null, null, null);

                if (mCursor != null) {
                    if (mCursor.getCount() > 0) {
                        uri = null;
                    } else {
                        rowID = mDb.insert(LOGIN_TABLE, "", values);
                    }
                }
                if (mCursor != null) {
                    mCursor.close();
                    mCursor.deactivate();
                }
                if (rowID > 0) {
                    uri = ContentUris.withAppendedId(LOGIN_URI, rowID);
                }
                break;
            case PLAN:
                rowID = mDb.insert(PLAN_TABLE, "", values);
                if (rowID > 0) {
                    uri = ContentUris.withAppendedId(PLAN_URI, rowID);
                }
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        if(uri != null){
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return uri;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        int count = 0;
        Cursor mCursor = null;
        String whereClause = null;
        switch (uriMatcher.match(uri)) {
            case LOGIN:
                mCursor = mDb.query(true, LOGIN_TABLE, null, KEY_USERID + "='" + values.getAsString(KEY_USERID)
                                + "' and " + KEY_PASSWORD + "='" + values.getAsString(KEY_PASSWORD) + "'",
                        null, null, null, null, null);

                if (mCursor != null) {
                    if (mCursor.getCount() > 0 && mCursor.moveToFirst()) {
                        count = mDb.update(LOGIN_TABLE, values,
                                KEY_USERID + "='" + values.getAsString(KEY_USERID) + "'",
                                selectionArgs);
                    } else {
                        //throw new IllegalArgumentException("User-Id doesn't exist Or Password Incorrect");
                    }
                }
                break;
            case LOGINID:
                count = mDb.update(LOGIN_TABLE, values,
                        KEY_ROWID + "=" + uri.getPathSegments().get(1),
                        selectionArgs);
                break;
            case PLAN:
                mCursor = mDb.query(true, PLAN_TABLE, null, selection,
                        null, null, null, null, null);

                if (mCursor != null) {
                    if (mCursor.getCount() > 0 && mCursor.moveToFirst()) {
                        count = mDb.update(PLAN_TABLE, values, selection,
                                selectionArgs);
                    } else {
                        throw new IllegalArgumentException("Plan doesn't exist");
                    }
                }
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        if(mCursor != null){
            mCursor.close();
            mCursor.deactivate();
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }

    //Helper class for createing and updating tables
    private static class DBHelper extends SQLiteOpenHelper {
        public DBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db)
        {
            db.execSQL(CREATE_LOGIN_TABLE);
            db.execSQL(CREATE_PLAN_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS" + LOGIN_TABLE);
            db.execSQL("DROP TABLE IF EXISTS" + PLAN_TABLE);

        }
    }
}
