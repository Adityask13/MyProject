package com.example.adity.netwroktracker;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.adity.netwroktracker.DataBaseHelpers.DBHelper;
import com.example.adity.netwroktracker.DataBaseHelpers.DataProvider;

public class ListPlansActivity extends Activity {

    Button btAdd;
    private Cursor planCursor;
    private ListView lvPListView;
    private TextView tvNoPlans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_plans);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        //planCursor = DBHelper.getInstance().getAllPlans(getApplicationContext());


        btAdd = (Button) findViewById(R.id.btAdd);
        tvNoPlans = (TextView) findViewById(R.id.tvNoLists);

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ListPlansActivity.this, CreatePlanActivity.class));
            }
        });

        //populateListView(lvPListView);

        //lvPListView.setOnCreateContextMenuListener(new );

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Select The Action");
        menu.add(0, v.getId(), 0, "Add Phone Number & Run");//groupId, itemId, order, title
       // menu.add(0, v.getId(), 0, "SMS");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item){

        boolean result = false;

        final int rowId = (int) ((AdapterView.AdapterContextMenuInfo)item.getMenuInfo()).id;
        if(item.getTitle()=="Add Phone Number & Run"){
            result = true;
            Intent settingsIntent = new Intent(ListPlansActivity.this,Settings.class);
            settingsIntent.putExtra(DataProvider.KEY_PLANID,rowId);
            startActivity(settingsIntent);

            //Toast.makeText(getApplicationContext(),"calling code :"+rowId,Toast.LENGTH_LONG).show();
            //return true;
        }
        else{
            return false;
        }
        return result;
    }


    private void populateListView(){

        planCursor = DBHelper.getInstance().getAllPlans(getApplicationContext());
        if(planCursor!=null) {
            String[] planName = new String[]{DataProvider.KEY_PLAN_NAME};
            int[] viewID = new int[]{R.id.tvPlanItem};
            SimpleCursorAdapter cursorAdapter;
            cursorAdapter = new SimpleCursorAdapter(getBaseContext(), R.layout.plan_list, planCursor, planName, viewID, 0);
            lvPListView = (ListView) findViewById(R.id.lvPlanList);
            lvPListView.setAdapter(cursorAdapter);
            registerForContextMenu(lvPListView);
            tvNoPlans.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        populateListView();
    }
}
