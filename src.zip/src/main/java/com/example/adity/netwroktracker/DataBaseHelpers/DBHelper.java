package com.example.adity.netwroktracker.DataBaseHelpers;


import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.util.Log;

import com.example.adity.netwroktracker.LoginActivity;

public class DBHelper {
    private static DBHelper dbHelper;

    private DBHelper() {

    }

    public static DBHelper getInstance() {
        if (dbHelper == null) {
            dbHelper = new DBHelper();
        }
        return dbHelper;
    }

    public boolean createUser(Context ctx, String userName, String password, String hint) {
        ContentValues cv = new ContentValues();
        cv.put(DataProvider.KEY_USERID, userName);
        cv.put(DataProvider.KEY_PASSWORD, password);
        cv.put(DataProvider.KEY_HINT, hint);
        Uri uri = ctx.getContentResolver().insert(DataProvider.LOGIN_URI, cv);
        return (uri != null) ? true : false;
    }


    public boolean createPlan(Context ctx, String name, int radius, String lat_long){
        //int planId = getPlanId(ctx, name);
        ContentValues cv = new ContentValues();
        cv.put(DataProvider.KEY_PLAN_NAME, name);
        cv.put(DataProvider.KEY_PLAN_LOGINID, getLoginId(ctx));
        cv.put(DataProvider.KEY_PLAN_RADIUS, radius);
        if(lat_long != null) {
            cv.put(DataProvider.KEY_PLAN_LAT_LONG, lat_long);
        }
        /*if(planId == -1) {
            return (ctx.getContentResolver().insert(DataProvider.PLAN_URI, cv)) != null ? true : false;
        } else {
            return false;
        }*/
        return (ctx.getContentResolver().insert(DataProvider.PLAN_URI, cv)) != null ? true : false;
    }

    private int getLoginId(Context ctx) {

        //sharedPreference
        SharedPreferences pref = ctx.getSharedPreferences("loginPref", Activity.MODE_PRIVATE);
        String userName = pref.getString(DataProvider.KEY_USERID,"");
        String selection = DataProvider.KEY_USERID +"='"+userName+"'";

        int loginId = -1;
       // Log.d("login name", "getLoginId: "+ selection);
        Cursor mCursor = ctx.getContentResolver().query(DataProvider.LOGIN_URI,
                null, selection, null, null);
        if(mCursor != null && mCursor.getCount() > 0) {
            if(mCursor.moveToFirst()) {
                loginId = mCursor.getInt(mCursor.getColumnIndex(DataProvider.KEY_ROWID));
            }
        }
        if(mCursor != null){
            mCursor.close();
            mCursor = null;
        }
       // Log.d("login id", "getLoginId: "+loginId);
        return loginId;
    }

    public boolean login(Context ctx, String userId, String password, boolean savePwd){
        ContentValues cv = new ContentValues();
        cv.put(DataProvider.KEY_USERID, userId);
        cv.put(DataProvider.KEY_PASSWORD, password);
        cv.put(DataProvider.KEY_SAVE_PWD, savePwd);
        cv.put(DataProvider.KEY_IS_LOGIN, true);
        return ctx.getContentResolver().update(DataProvider.LOGIN_URI, cv,
                null, null) > 0 ? true : false;
    }

    public Cursor getAllPlans(Context ctx){
        int loginId = getLoginId(ctx);
        if(loginId != -1) {
            return ctx.getContentResolver().query(DataProvider.PLAN_URI,
                    null, DataProvider.KEY_PLAN_LOGINID + "=" + loginId, null, DataProvider.KEY_PLAN_NAME);
        } else {
            return null;
        }
    }

    public Cursor getPlanDetails(Context ctx, int rowID){
        return ctx.getContentResolver().query(DataProvider.PLAN_URI,null,
                DataProvider.KEY_ROWID +" = "+ rowID,null,null);
    }
}