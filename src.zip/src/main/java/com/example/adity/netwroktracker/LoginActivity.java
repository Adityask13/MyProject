package com.example.adity.netwroktracker;

import android.*;
import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.adity.netwroktracker.DataBaseHelpers.DBHelper;
import com.example.adity.netwroktracker.DataBaseHelpers.DataProvider;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    Button btLogin;
    EditText etUserName, etPassword;
    TextView tvRegister;
    SharedPreferences loginPreferences = null;
    public String userName;
    public String password;

    private static String[] PERMISSIONS = {android.Manifest.permission.ACCESS_COARSE_LOCATION,
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
            android.Manifest.permission.READ_SMS,
            android.Manifest.permission.SEND_SMS,
            android.Manifest.permission.INTERNET,
            android.Manifest.permission.CALL_PHONE,
            android.Manifest.permission.READ_PHONE_STATE
    };

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        int currentapiVersion = Build.VERSION.SDK_INT;
        if (currentapiVersion >= Build.VERSION_CODES.LOLLIPOP){
            // Do something for lollipop and above versions
            requestPermissions(PERMISSIONS,100);
        }


        loginPreferences = getSharedPreferences("loginPref", Activity.MODE_PRIVATE);

        btLogin = (Button) findViewById(R.id.btLogin);
        etUserName = (EditText) findViewById(R.id.etUserName);
        etPassword = (EditText) findViewById(R.id.etPassword);
        tvRegister = (TextView) findViewById(R.id.tvRegister);

        etUserName.setText("aditya");
        etPassword.setText("aditya123");

        btLogin.setOnClickListener(this);
        tvRegister.setOnClickListener(this);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_login, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btLogin:
                userName = etUserName.getText().toString();
                password = etPassword.getText().toString();

                if(userName.length()>0 && password.length()>0){
                    if(DBHelper.getInstance().login(getApplicationContext(),userName,password,true)){
                        savePreferences(userName);
                        Intent planIntent = new Intent(getApplicationContext(),ListPlansActivity.class);
                        startActivity(planIntent);
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Autenticatio Failed",Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(getApplicationContext(),"Enter UserName and Password",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.tvRegister:
                startActivity(new Intent(this,RegisterActivity.class));
        }
    }

    protected void savePreferences(String userName){
        SharedPreferences.Editor editor = loginPreferences.edit();
        editor.putString(DataProvider.KEY_USERID, userName);
        editor.commit();
    }
}
