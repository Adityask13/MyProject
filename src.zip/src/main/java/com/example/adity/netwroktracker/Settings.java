package com.example.adity.netwroktracker;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Contacts;
import android.provider.ContactsContract;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.adity.netwroktracker.DataBaseHelpers.DataProvider;

public class Settings extends AppCompatActivity {


    Button btAdd, btRun;
    EditText etContact;
    private static final int CONTACT_PICKER_RESULT = 1001;
    private int planId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        btAdd = (Button) findViewById(R.id.btAdd);
        btRun = (Button) findViewById(R.id.btRun);

        etContact =(EditText) findViewById(R.id.etContact);


        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent contactPickerIntent = new Intent(Intent.ACTION_PICK,
                        ContactsContract.Contacts.CONTENT_URI);
                startActivityForResult(contactPickerIntent, CONTACT_PICKER_RESULT);
            }
        });

        Bundle b = getIntent().getExtras();
        planId = b.getInt(DataProvider.KEY_PLANID);

        btRun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = etContact.getText().toString();
                Intent runIntent = new Intent(Settings.this, RunOnMap.class);
                runIntent.putExtra("phoneNumber", phoneNumber);
                runIntent.putExtra(DataProvider.KEY_PLANID, planId);

                Log.d("Plan ID", "onClick: "+planId);
                Log.d("Phone Number", "onClick: "+phoneNumber);
                startActivity(runIntent);
            }
        });


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK)
        {
            Uri contactData = data.getData();
            Cursor c = managedQuery(contactData, null, null, null, null);

            if (c.moveToFirst())
            {
                String id = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts._ID));

                String hasPhone =
                        c.getString(c.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER));

                if (hasPhone.equalsIgnoreCase("1"))
                {
                    Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = "+ id,null, null);
                    phones.moveToFirst();
                    String cNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    // Toast.makeText(getApplicationContext(), cNumber, Toast.LENGTH_SHORT).show();
                    etContact.setText(cNumber);
                }
            }
        }
    }
}
