package com.example.adity.netwroktracker;

import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.adity.netwroktracker.DataBaseHelpers.DBHelper;

public class CreatePlanActivity extends AppCompatActivity implements View.OnClickListener{

    private Button btSave, btCancel, btSelectRoute;
    private EditText etPlanName, etRadius;
    private String latLng;
    private int radius;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_plan);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        etPlanName = (EditText) findViewById(R.id.etPlanName);
        etRadius =(EditText) findViewById(R.id.etRadius);

        btSave = (Button) findViewById(R.id.btSave);
        btCancel = (Button) findViewById(R.id.btCancel);
        btSelectRoute = (Button) findViewById(R.id.btSelectRoute);

        btSave.setOnClickListener(this);
        btCancel.setOnClickListener(this);
        btSelectRoute.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btSave:
                String planName = etPlanName.getText().toString();
                String radii = etRadius.getText().toString();
                if(planName.length()>0 && radii.length()>0 ){
                    if(DBHelper.getInstance().createPlan(getApplicationContext(),planName,radius,latLng))
                    {
                        Toast.makeText(getApplicationContext(),"Plan Created", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Plan Already Exists",Toast.LENGTH_SHORT).show();
                    }

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Enter all fields",Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.btCancel:
                finish();
                break;
            case R.id.btSelectRoute:
                LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

                if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                    Toast.makeText(getApplicationContext(),"GPS is disabled",Toast.LENGTH_SHORT).show();
                    Toast.makeText(getApplicationContext(),"Enable GPS and Try",Toast.LENGTH_SHORT).show();
                    // enableGPS();
                    //finish();
                }else{
                Intent selectMarkerIntent = new Intent(getApplicationContext(),SelectRouteActivity.class);
                startActivityForResult(selectMarkerIntent,1);}
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            if(resultCode == RESULT_OK){
                if(data!= null){
                    latLng = data.getStringExtra("latLng");
                    radius = Integer.parseInt(data.getStringExtra("radius"));
                    etRadius.setText(radius+"");
                    Log.d("CreatePlanAcivity", "onActivityResult: "+latLng);
                    Log.d("CreatePlanAcivity", "onActivityResult: "+radius);
                }
            }
            else{
                Toast.makeText(getApplicationContext(),"No Marker Selected",Toast.LENGTH_SHORT).show();
            }
        }
    }
}
